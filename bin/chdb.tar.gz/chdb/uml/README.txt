HOW TO READ *.uml files ?
-------------------------

You should install plantuml - see http://plantuml.com
